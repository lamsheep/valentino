document.addEventListener("DOMContentLoaded", function() {


    var movingButton = document.getElementById('movingButton');
    movingButton.addEventListener('mouseover', function() {
        // Generate new random positions
        var randomTop = Math.floor(Math.random() * 380);
        var randomLeft = Math.floor(Math.random() * 920);

        // Apply the new positions to the button
        movingButton.style.top = randomTop + 'px';
        movingButton.style.left = randomLeft + 'px';
    });
});